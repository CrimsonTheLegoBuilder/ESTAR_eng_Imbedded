#ifndef _CONFIG_H_
#define _CONFIG_H_

#include <Arduino.h>
#include <stdio.h>
#include <math.h>
#include <SoftwareSerial.h>

typedef long long ll;
typedef double ld;

#endif